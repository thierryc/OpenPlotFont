# PF CAD lc_opengost-ar

Source: [https://github.com/LibreCAD/LibreCAD](https://github.com/LibreCAD/LibreCAD)

License: SIL OFL 1.1. Retain every accompanying notice and SOURCE file with redistribution.

# Author:            stranger573 <stranger573@mail.ru>
# License:           SIL OPEN FONT LICENSE Version 1.1

- [Author/source link](https://github.com/LibreCAD/LibreCAD)

678 glyphs; 677 scalar mappings; 0 resolved kerning pairs.



Independent strokes retain their order and pen lifts. No automatic script joining, stroke-width expansion, or device commands. This is geometry-only OpenPlotFont 0.3; retained unencoded alternates/ligatures have no automatic substitutions.
